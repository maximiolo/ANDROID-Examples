package pl.imiolo.droid.wawel.tango;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import org.apache.http.util.ByteArrayBuffer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;


public class MainActivity extends Activity {

	String fileName;
	Boolean isError=false;
	private int _progress = 0;
	private ProgressDialog _progressDialog;
	private Handler _progressHandler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		TangoEngine.LoadBaseData(getBaseContext());
		
		
	}

	public void program(View view) {
		Intent intent = new Intent(MainActivity.this, ProgramActivity.class);
		intent.putExtra(TangoEngine.showName, TangoEngine.showType.Program);
		startActivity(intent);
	}

	public void milonga(View view) {
		Intent intent = new Intent(MainActivity.this, ProgramActivity.class);
		intent.putExtra(TangoEngine.showName, TangoEngine.showType.Milonga);
		startActivity(intent);
	}

	public void workshop(View view) {
		Intent intent = new Intent(MainActivity.this, ProgramActivity.class);
		intent.putExtra(TangoEngine.showName, TangoEngine.showType.WorkShop);
		startActivity(intent);
	}

	public void myEvents(View view) {
		Intent intent = new Intent(MainActivity.this, ProgramActivity.class);
		intent.putExtra(TangoEngine.showName, TangoEngine.showType.MyEvents);
		startActivity(intent);
	}

	public void artist(View view) {
		Intent intent = new Intent(MainActivity.this, ArtistGroupActivity.class);
		startActivity(intent);
	}

	public void other(View view) {
		Intent intent = new Intent(MainActivity.this, OtherActivity.class);
		startActivity(intent);
	}

	public void news(View view) {
		Intent intent = new Intent(MainActivity.this, NewsActivity.class);
		intent.putExtra(TangoEngine.showMsg, TangoEngine.showMessage.News);
		startActivity(intent);
	}

	public void update(View view) {
		try {
			_progressHandler = new Handler() {

				public void handleMessage(Message msg) {
					super.handleMessage(msg);
					if (_progress >= 3) {
						_progressDialog.dismiss();
					} else {
						new BackgroundTast().execute(_progress);
						_progressDialog.incrementProgressBy(30);
						_progress++;
					}

				}
			};

			showDialog(1);
			_progress = 0;
			_progressDialog.setProgress(0);
			_progressHandler.sendEmptyMessage(0);

		} catch (Exception exc) {
			isError=true;
			Log.d("Tango", "exc 1:" + exc.toString());
		}
	}

	@SuppressWarnings("deprecation")
	public void DownloadFromUrl(String downloadUrl, String fileName)
			throws Exception {
		this.fileName = fileName;
		try {
			File root = android.os.Environment.getExternalStorageDirectory();
			File dir = new File(root.getAbsolutePath() + File.separator
					+ "json");

			if (!dir.exists()) {
				dir.mkdirs();
				if (!dir.exists()) {
					dir = getDir("json", Context.MODE_WORLD_WRITEABLE);
					if (!dir.exists()) {
						dir.mkdirs();
						if (!dir.exists()) {
							return;
						}
					}
				}
			}

			URL url = new URL(downloadUrl);
			File file = new File(dir, fileName + ".json");
			// Thread.sleep(1000);
			URLConnection urlConn = url.openConnection();
			InputStream is = urlConn.getInputStream();
			BufferedInputStream buffer = new BufferedInputStream(is);

			ByteArrayBuffer byteBuff = new ByteArrayBuffer(5000);
			int current = 0;
			while ((current = buffer.read()) != -1) {
				byteBuff.append(current);
			}

			FileOutputStream fos = new FileOutputStream(file);
			fos.write(byteBuff.toByteArray());
			fos.flush();
			fos.close();
			saveToSharedPreferences(fileName, file.getAbsolutePath());
		} catch (Exception exc) {
			isError=true;
			Log.d("Tango", "exc 2:" + exc.toString());
		}

	}

	private void saveToSharedPreferences(String key, String value) {
		SharedPreferences sp = getSharedPreferences(TangoEngine.SPName,
				MODE_PRIVATE);
		sp.edit().putString(key, value).commit();

	}

	private String getSharedPreferences(String key) {
		SharedPreferences sp = getSharedPreferences(TangoEngine.SPName,
				MODE_PRIVATE);
		return sp.getString(key, "");
	}

	private class BackgroundTast extends AsyncTask<Integer, Void, String> {

		@Override
		protected String doInBackground(Integer... url) {

			try {
				switch (url[0]) {
				case 0:
					DownloadFromUrl(TangoEngine.baseUrl, TangoEngine.base);
					break;
				case 1:
					DownloadFromUrl(TangoEngine.newsUrl, TangoEngine.news);
					break;
				case 2:
					// refresh BaseData
					TangoEngine.reloadBaseData(getBaseContext());
					break;
				}
			} catch (Exception exc) {
				isError=true;
				Log.d("Tango", "exc 2:" + exc.toString());
			}
			return "";
		}

		protected void onPostExecute(String _ss) {
			_progressHandler.sendEmptyMessageDelayed(0, 1);
			if(isError)
				showDialog(2);
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case 1:
			_progressDialog = new ProgressDialog(this);
			_progressDialog.setTitle(getString(R.string.download_file));
			_progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			return _progressDialog;

		case 2:
			
			return new AlertDialog.Builder(this)
			.setTitle(R.string.download_fail)
			.setIcon(android.R.drawable.ic_dialog_info)
			.setMessage(R.string.download_fail_message)
			.setNeutralButton("OK", null)
			.create();

		}
		return null;
	}
}
