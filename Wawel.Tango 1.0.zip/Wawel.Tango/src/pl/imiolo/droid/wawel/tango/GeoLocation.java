package pl.imiolo.droid.wawel.tango;

import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;

public class GeoLocation {
	static Context context;
	private static GeoLocation geoLocation;
	static double longitude, lattitude;

	private GeoLocation(Context pcontext) {
		context = pcontext;
		TangoEngine.LoadBaseData(context);
	}

	public static GeoLocation Instane(Context pcontext) {
		if (geoLocation == null)
			geoLocation = new GeoLocation(pcontext);
		return geoLocation;
	}

	public Intent showGeo(Integer id) {
		Uri uri = Uri.parse("geo:"
				+ TangoEngine.baseData.Places.get(id).Latitude + ","
				+ TangoEngine.baseData.Places.get(id).Lonngitude);
		return new Intent(Intent.ACTION_VIEW, uri);

	}

	public Intent showGoogleMaps(Integer id) {
		Uri uri = Uri.parse("http://maps.google.com/maps?saddr=" + lattitude
				+ "," + longitude + "&daddr="
				+ TangoEngine.baseData.Places.get(id).Latitude + ","
				+ TangoEngine.baseData.Places.get(id).Lonngitude);
		return new Intent(Intent.ACTION_VIEW, uri);

	}

	public Boolean checkLocation() {

		LocationManager lm = (LocationManager) context
				.getSystemService(Context.LOCATION_SERVICE);
		Criteria c = new Criteria();
		c.setAccuracy(Criteria.ACCURACY_FINE);
		String provider = lm.getBestProvider(c, true);
		if (provider != null) {

			Location l = lm.getLastKnownLocation(provider);
			if (l != null) {
				double lat = l.getLatitude();
				double lng = l.getLongitude();

				lattitude = l.getLatitude();
				longitude = l.getLongitude();
				return true;
			}
		}
		return false;
	}

}
