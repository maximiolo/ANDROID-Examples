package pl.imiolo.droid.wawel.tango;

public class Shopp {

public String Name;
public String NamePl;
	
}
