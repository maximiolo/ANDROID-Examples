package pl.imiolo.droid.wawel.tango;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.widget.Toast;

public class JsonLoadData {

	Context context;

	public JsonLoadData(Context context) {
		super();
		this.context = context;
	}

	public BaseData getBaseData() {

		BaseData base = new BaseData();
		JSONObject _o = getJson(TangoEngine.base);

		base.Events = getEvents(_o);
		base.Names = getName(_o);
		base.Artists = getArtist(_o);
		base.Days = getDay(_o);
		base.Hours = getHours(_o);
		base.Places = getPlace(_o);
		base.Contact = getContact(_o);
		// base.Others = getNews(_o, "others");
		base.Food = getFood(_o);
		base.Legends = getNews(_o, "legends");
		base.Shoop = getShopp(_o);

		try {
			_o = getJson(TangoEngine.news);
			base.News = getNews(_o, "news");
		} catch (Exception exc) {
			base.News = new HashMap<Integer, News>();
		}
		return base;
	}

	private Boolean isFileInMemory(String key) {
		SharedPreferences sp = context.getSharedPreferences(TangoEngine.SPName,
				context.MODE_PRIVATE);
		String _s = sp.getString(key, "");
		return !_s.equals("");
	}

	private String getFileInMemory(String key) {
		SharedPreferences sp = context.getSharedPreferences(TangoEngine.SPName,
				context.MODE_PRIVATE);
		return sp.getString(key, "");
	}

	private JSONObject getJson(String url) {

		// Toast.makeText(context, getFileInMemory(url), 1).show();
		InputStream is = null;
		String result = "";
		JSONObject jArray = null;
		try {
			File file1 = new File(getFileInMemory(url));
			// Toast.makeText(context, file1.exists()+" ",1).show();

			if (isFileInMemory(url) && file1.exists()) {

				// AssetManager am = context.getAssets();
				// is = am.open(url + ".json");
				is = new FileInputStream(file1);
				String line = "";
				BufferedReader br = new BufferedReader(new FileReader(file1));
				while ((line = br.readLine()) != null) {
					result += line + "\n";
				}
			} else {
				AssetManager am = context.getAssets();
				is = am.open(url + ".json");
			}
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "UTF-8"));
			StringBuilder sb = new StringBuilder();
			String line = "";
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
			jArray = new JSONObject(result);
		} catch (Exception e) {
			// Toast.makeText(context,"tutaj: "+ e.toString(), 1).show();
		}
		return jArray;
	}

	private Map<Integer, Name> getName(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Name> lName = new HashMap<Integer, Name>();
		Name name;
		try {
			array = jObject.getJSONArray("name");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				name = new Name();
				name.Id = _o.getInt("id");
				name.Name = _o.getString("name");
				name.NamePL = _o.getString("name_pl");

				lName.put(name.Id, name);
			}
		} catch (JSONException e) {
			// Toast.makeText(context, e.toString(), 1).show();
		}
		return lName;
	}

	private Map<Integer, Artist> getArtist(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Artist> lArtist = new HashMap<Integer, Artist>();
		Artist artist;
		try {
			array = jObject.getJSONArray("artist");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				artist = new Artist();
				artist.Id = _o.getInt("id");
				artist.Name = _o.getString("name");
				artist.Description = _o.getString("description");

				lArtist.put(artist.Id, artist);
			}
		} catch (JSONException e) {
			// Toast.makeText(context, e.toString(), 1).show();
		}
		return lArtist;
	}

	private Map<Integer, Day> getDay(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Day> lDay = new HashMap<Integer, Day>();
		Day day;
		try {
			array = jObject.getJSONArray("day");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				day = new Day();
				day.Id = _o.getInt("id");
				day.Name = _o.getString("name");
				day.NamePL = _o.getString("name_pl");
				day.Date = _o.getString("date");
				day.DateTab = _o.getString("date_tab");

				lDay.put(day.Id, day);
			}
		} catch (JSONException e) {
			// Toast.makeText(context, e.toString(), 1).show();
		}
		return lDay;
	}

	private Map<Integer, Hours> getHours(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Hours> lHours = new HashMap<Integer, Hours>();
		Hours hours;
		try {
			array = jObject.getJSONArray("hours");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				hours = new Hours();
				hours.Id = _o.getInt("id");
				hours.Hour = _o.getString("hour");
				hours.HourPL = _o.getString("hour_pl");

				lHours.put(hours.Id, hours);
			}
		} catch (JSONException e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		return lHours;
	}

	private Map<Integer, Events> getEvents(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Events> lEvents = new HashMap<Integer, Events>();
		Events events;
		try {
			array = jObject.getJSONArray("events");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				events = new Events();
				events.Id = _o.getInt("id");
				events.DayId = _o.getInt("id_day");
				events.DayIdReal = _o.getInt("id_day_real");
				events.PlaceId = _o.getInt("id_place");
				events.HourIdStart = _o.getInt("from_h");
				events.HourIdStop = _o.getInt("to_h");
				events.NameId = _o.getInt("id_name");
				events.EntraceId = _o.getInt("id_entrance");
				events.DescriptionId = _o.getInt("description");
				events.ArtistId = _o.getInt("id_artist");
				lEvents.put(events.Id, events);
			}
		} catch (JSONException e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		return lEvents;
	}

	private Map<Integer, Place> getPlace(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Place> lPlace = new HashMap<Integer, Place>();
		Place place;
		try {
			array = jObject.getJSONArray("place");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				place = new Place();
				place.Id = _o.getInt("id");
				place.Name = _o.getString("name");
				place.Street = _o.getString("street");
				place.Lonngitude = _o.getString("longitude");
				place.Latitude = _o.getString("latitude");

				lPlace.put(place.Id, place);
			}
		} catch (JSONException e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		return lPlace;
	}

	private Map<Integer, News> getNews(JSONObject jObject, String table) {
		JSONArray array = null;
		Map<Integer, News> lNews = new HashMap<Integer, News>();
		News news;
		try {
			array = jObject.getJSONArray(table);
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				news = new News();
				news.Id = _o.getInt("id");
				news.Name = _o.getString("name");
				news.NamePl = _o.getString("name_pl");
				news.Description = _o.getString("description");
				news.DescriptionPl = _o.getString("description_pl");
				lNews.put(news.Id, news);
			}
		} catch (JSONException e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		return lNews;
	}

	private Map<Integer, Contact> getContact(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Contact> lContact = new HashMap<Integer, Contact>();
		Contact contact;
		try {
			array = jObject.getJSONArray("contact");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				contact = new Contact();
				contact.Id = _o.getInt("id");
				contact.Name = _o.getString("name");
				contact.Number = _o.getString("number");
				contact.Language = _o.getString("language");

				lContact.put(contact.Id, contact);
			}
		} catch (JSONException e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		return lContact;
	}

	private Map<Integer, Food> getFood(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Food> lfood = new HashMap<Integer, Food>();
		Food food;
		try {
			array = jObject.getJSONArray("food");
			for (int i = 0; i < array.length(); i++) {

				JSONObject _o = array.getJSONObject(i);
				food = new Food();
				food.Id = _o.getInt("id");
				food.Description = _o.getString("description");
				food.DescriptionPl = _o.getString("description_pl");
				food.PlaceId = _o.getInt("place_id");

				lfood.put(food.Id, food);
			}
		} catch (JSONException e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		return lfood;
	}

	private Shopp getShopp(JSONObject jObject) {
		JSONArray array = null;
		Map<Integer, Food> lfood = new HashMap<Integer, Food>();
		Shopp shopp = new Shopp();
		try {
			array = jObject.getJSONArray("shopp");
			for (int i = 0; i < array.length(); i++) {
				JSONObject _o = array.getJSONObject(i);
				shopp.Name = _o.getString("description");
				shopp.NamePl = _o.getString("description_pl");
			}
		} catch (JSONException e) {
			Toast.makeText(context, e.toString(), 1).show();
		}
		return shopp;
	}
}
