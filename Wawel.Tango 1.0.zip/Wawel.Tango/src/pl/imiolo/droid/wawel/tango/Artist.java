package pl.imiolo.droid.wawel.tango;

public class Artist {

	public int Id;
	public String Name;
	public String Description;
}

