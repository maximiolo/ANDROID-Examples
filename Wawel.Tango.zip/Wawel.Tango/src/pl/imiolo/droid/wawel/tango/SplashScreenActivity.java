package pl.imiolo.droid.wawel.tango;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

public class SplashScreenActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash_screen);

		TangoEngine.LoadBaseData(getBaseContext());

		
		new Handler().postDelayed(new Thread() {
			public void run() {
				Intent intent = new Intent(SplashScreenActivity.this,
						MainActivity.class);
				startActivity(intent);
				SplashScreenActivity.this.finish();
				overridePendingTransition(R.layout.fadein, R.layout.fadeout);
			}
		}, TangoEngine.splashTime);

	}

}