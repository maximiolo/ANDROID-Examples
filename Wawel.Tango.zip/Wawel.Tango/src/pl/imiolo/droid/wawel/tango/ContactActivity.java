package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pl.imiolo.droid.wawel.tango.R.drawable;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class ContactActivity extends Activity {

	List<HashMap<String, Object>> fillMaps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_contact);
		TangoEngine.LoadBaseData(getBaseContext());
		try {
			ListView l = (ListView) findViewById(R.id.listViewContact);

			String[] from = { "name", "number", "language" };
			int[] to = { R.id.txContact, R.id.txContactNumber, R.id.imageFlag };

			fillMaps = new ArrayList<HashMap<String, Object>>();

			for (int i = 1; i <= TangoEngine.baseData.Contact.size(); i++) {
				HashMap<String, Object> map = new HashMap<String, Object>();
				map.put("name", TangoEngine.baseData.Contact.get(i).Name);
				map.put("number", TangoEngine.baseData.Contact.get(i).Number);
				map.put("language",
						TangoEngine.baseData.Contact.get(i).Language);

				fillMaps.add(map);
			}
			l.setAdapter(new MyAdapter(getBaseContext(), fillMaps,
					R.layout.contact_item, from, to));
		} catch (Exception exc) {
			Toast.makeText(getBaseContext(), exc.toString(), 1).show();
		}
	}

	private class MyAdapter extends SimpleAdapter {

		Context context;

		@SuppressWarnings("deprecation")
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = super.getView(position, convertView, parent);
			
			view.setBackgroundColor(getResources().getColor(R.color.gray_light));
			view.setAlpha(Float.parseFloat(getString(R.string.grid_opacity)));
			
			try {
				Button btnCall = (Button) view.findViewById(R.id.btnCall);
				btnCall.setTag(fillMaps.get(position).get("number").toString());
				btnCall.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Button imageAdd = (Button) v;

						Intent intent = new Intent(Intent.ACTION_DIAL);
						intent.setData(Uri.parse("tel:"
								+ imageAdd.getTag().toString()));
						startActivity(intent);
					}
				});

				ImageView image = (ImageView) view.findViewById(R.id.imageFlag);

				if (fillMaps.get(position).get("language").toString()
						.equals("English")) {
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.uk));
				} 
				else {
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.poland));

				}
			} catch (Exception exc) {
				Toast.makeText(getBaseContext(), exc.toString(), 1).show();
			}
			return view;

		}

		public MyAdapter(Context context, List<? extends Map<String, ?>> data,
				int resource, String[] from, int[] to) {

			super(context, data, resource, from, to);
			this.context = context;
			// TODO Auto-generated constructor stub
		}
	}

}
