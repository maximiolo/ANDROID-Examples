package pl.imiolo.droid.wawel.tango;

public class Events {

	public int Id;
	public int DayId;
	public int DayIdReal;
	public int PlaceId;
	public int HourIdStart;
	public int HourIdStop;
	public int NameId;
	public int EntraceId;
	public int DescriptionId;
	public int ArtistId;
	}

