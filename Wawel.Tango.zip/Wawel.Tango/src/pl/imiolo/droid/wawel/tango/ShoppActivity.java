package pl.imiolo.droid.wawel.tango;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class ShoppActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shopp);
		
		TangoEngine.LoadBaseData(getBaseContext());
		
		TextView tx=(TextView)findViewById(R.id.textViewShopp);
		tx.setText(SharedPrefEvents.Instance(getBaseContext()).getLanguage()? TangoEngine.baseData.Shoop.NamePl: TangoEngine.baseData.Shoop.Name);
		
		
	}

	

}
