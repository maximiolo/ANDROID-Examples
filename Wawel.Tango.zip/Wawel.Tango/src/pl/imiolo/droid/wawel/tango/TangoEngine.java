package pl.imiolo.droid.wawel.tango;

import android.content.Context;

public class TangoEngine {

	public final static int splashTime = 4000;
	// SharedPreferences
	public final static String SPName = "maxdroidim.waweltango";
	public final static String base = "base";
	public final static String news = "news";

	public final static String myEvents = "myEvents";

	public final static String baseUrl = "http://wawel-tango.pl/base.json";
	public final static String newsUrl = "http://wawel-tango.pl/news.json";

	public static BaseData baseData;

	public static void reloadBaseData(Context context) {
		JsonLoadData d = new JsonLoadData(context);
		TangoEngine.baseData = d.getBaseData();
	}

	public static void LoadBaseData(Context context) {
		if (TangoEngine.baseData == null) {
			JsonLoadData d = new JsonLoadData(context);
			TangoEngine.baseData = d.getBaseData();
		}
	}

	public static final String day = "day";

	public static final String tagAdd = "tagAdd";

	public static final String showName = "showName";

	public static enum showType {
		Program, Milonga, WorkShop, MyEvents
	};

	/*public static final String showMsg = "showMsg";

	public static enum showMessage {
		News, Legends, Food, Sposors, Shopp, Herigate
	};*/

	public static final String streetPl = " ul. ";
	public static final String streetEn = " St.";

	public static final String artistId = "artistId";

	public static final String mapId = "mapId";
}
