package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class GridActivity extends Activity {

	private List<HashMap<String, Object>> fillMaps;
	HashMap<String, Object> map;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_grid);
		TangoEngine.LoadBaseData(getBaseContext());

		if (getIntent() != null && getIntent().getExtras() != null) {
			Bundle extras = getIntent().getExtras();
			int i = extras.getInt(TangoEngine.day);

			ListView list = (ListView) findViewById(R.id.listViewGrid);

			String[] from = { "date", "description", "adress", "artist" };
			int[] to = { R.id.txTime, R.id.txMessage, R.id.btnPlace,
					R.id.txArtist };
			fillMaps = new ArrayList<HashMap<String, Object>>();

			for (int z = 1; z <= TangoEngine.baseData.Events.size(); z++) {
				if (TangoEngine.baseData.Events.get(z).DayId == i) {

					switch ((TangoEngine.showType) extras
							.get(TangoEngine.showName)) {
					case Program:
						addToMap(z);
						break;
					case Milonga:
						if (checkMilonga(TangoEngine.baseData.Events.get(z).NameId))
							addToMap(z);
						break;
					case WorkShop:
						if (checkWorkshop(TangoEngine.baseData.Events.get(z).NameId))
							addToMap(z);
						break;
					case MyEvents:
						if (SharedPrefEvents.Instance(getBaseContext())
								.isEventAdded(z))
							addToMap(z);
						break;
					}

				}
			}

			list.setAdapter(new MyAdapter(getBaseContext(), fillMaps,
					R.layout.grid_item, from, to));
		}
	}

	private Boolean checkMilonga(Integer id) {
		if (id.equals(1) || id.equals(2) || id.equals(4) || id.equals(6)
				|| id.equals(7) || id.equals(8) || id.equals(10)
				|| id.equals(42))
			return true;
		return false;
	}

	private Boolean checkWorkshop(Integer id) {
		if (id.equals(3))
			return true;
		return false;
	}

	private void addToMap(Integer z) {
		map = new HashMap<String, Object>();
		String f = TangoEngine.baseData.Hours.get(TangoEngine.baseData.Events
				.get(z).HourIdStart).Hour;
		String t = TangoEngine.baseData.Hours.get(TangoEngine.baseData.Events
				.get(z).HourIdStop).Hour;

		String entrance = SharedPrefEvents.Instance(getBaseContext())
				.getLanguage() ? TangoEngine.baseData.Names
				.get(TangoEngine.baseData.Events.get(z).EntraceId).NamePL
				: TangoEngine.baseData.Names.get(TangoEngine.baseData.Events
						.get(z).EntraceId).Name;
		String n = SharedPrefEvents.Instance(getBaseContext()).getLanguage() ? TangoEngine.baseData.Names
				.get(TangoEngine.baseData.Events.get(z).NameId).NamePL
				: TangoEngine.baseData.Names.get(TangoEngine.baseData.Events
						.get(z).NameId).Name;

		String d = SharedPrefEvents.Instance(getBaseContext()).getLanguage() ? TangoEngine.baseData.Names
				.get(TangoEngine.baseData.Events.get(z).DescriptionId).NamePL
				: TangoEngine.baseData.Names.get(TangoEngine.baseData.Events
						.get(z).DescriptionId).Name;

		String temp = SharedPrefEvents.Instance(getBaseContext()).getLanguage() ? TangoEngine.streetPl
				: "";

		String temp1 = SharedPrefEvents.Instance(getBaseContext())
				.getLanguage() ? "" : TangoEngine.streetEn;
		String a = TangoEngine.baseData.Places.get(TangoEngine.baseData.Events
				.get(z).PlaceId).Name
				+ "\n"
				+ temp
				+ TangoEngine.baseData.Places.get(TangoEngine.baseData.Events
						.get(z).PlaceId).Street + temp1;

		map.put("date", f + " - " + t + "  " + n + " " + entrance);
		map.put("description", d);
		map.put("adress", a);
		map.put("artist", TangoEngine.baseData.Artists
				.get(TangoEngine.baseData.Events.get(z).ArtistId).Name);
		map.put("adress_id", TangoEngine.baseData.Events.get(z).PlaceId);
		map.put("event_id", TangoEngine.baseData.Events.get(z).Id);
		fillMaps.add(map);
	}

	private class MyAdapter extends SimpleAdapter {

		Context context;

		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			View view = super.getView(position, convertView, parent);
			view.setBackgroundColor(getResources().getColor(R.color.gray_light));
			view.setAlpha(Float.parseFloat(getString(R.string.grid_opacity)));

			Button imageAdd = (Button) view.findViewById(R.id.buttonAdd);
			imageAdd.setTag(fillMaps.get(position).get("event_id"));
			Button imageMinus = (Button) view.findViewById(R.id.buttonMinus);
			imageMinus.setTag(fillMaps.get(position).get("event_id"));

			if (SharedPrefEvents.Instance(context).isEventAdded(
					Integer.parseInt(fillMaps.get(position).get("event_id")
							.toString()))) {
				imageAdd.setVisibility(View.VISIBLE);
				imageMinus.setVisibility(View.GONE);
			} else {
				imageMinus.setVisibility(View.VISIBLE);
				imageAdd.setVisibility(View.GONE);
			}

			imageAdd.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Button imageAdd = (Button) v;
					SharedPrefEvents.Instance(context).setEvent(
							Integer.parseInt(imageAdd.getTag().toString()),
							!SharedPrefEvents.Instance(context).isEventAdded(
									Integer.parseInt(imageAdd.getTag()
											.toString())));
					notifyDataSetChanged();
				}
			});

			imageMinus.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Button imageMinus = (Button) v;
					SharedPrefEvents.Instance(context).setEvent(
							Integer.parseInt(imageMinus.getTag().toString()),
							!SharedPrefEvents.Instance(context).isEventAdded(
									Integer.parseInt(imageMinus.getTag()
											.toString())));
					notifyDataSetChanged();
				}
			});
			Button imageMap = (Button) view.findViewById(R.id.btnPlace);
			imageMap.setTag(fillMaps.get(position).get("adress_id"));
			imageMap.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					Button imageMap = (Button) v;
					ShowMaps(Integer.parseInt(imageMap.getTag().toString()));
				}
			});
			return view;
		}

		public MyAdapter(Context context, List<? extends Map<String, ?>> data,
				int resource, String[] from, int[] to) {

			super(context, data, resource, from, to);
			this.context = context;
		}
	}

	private void ShowMaps(int id) {

		if (!GeoLocation.Instane(getBaseContext()).checkLocation()) {
			startActivity(GeoLocation.Instane(getBaseContext()).showGeo(id));
		} else {
			showDialog(id);
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		final Integer idPlace = id;
		return new AlertDialog.Builder(this)
				.setTitle(R.string.maps)
				.setIcon(android.R.drawable.ic_dialog_map)
				.setMessage(R.string.maps_desc)
				.setPositiveButton(R.string.title_activity_other,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								startActivity(GeoLocation.Instane(
										getBaseContext()).showGeo(idPlace));
							}
						})
				.setNegativeButton("GoogleMaps",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								startActivity(GeoLocation.Instane(
										getBaseContext()).showGoogleMaps(
										idPlace));
							}
						}).create();
	}

}
