package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class SponsorsActivity extends Activity {

	List<HashMap<String, Object>> fillMaps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sponsors);

		TangoEngine.LoadBaseData(getBaseContext());

		try {
			ListView l = (ListView) findViewById(R.id.listViewSponsors);

			String[] from = { "name", "image" };
			int[] to = { R.id.txSponsors, R.id.imageSponsor };

			fillMaps = new ArrayList<HashMap<String, Object>>();

			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("name", getString(R.string.patronage));
			map.put("number", R.drawable.ambasad);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.krakow);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.media));
			map.put("number", R.drawable.tvp);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.radio);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.krakowpl);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.nestro);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.tanz);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.partners));
			map.put("number", R.drawable.akademia);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.porfiesta);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.kultura);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.poka);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.negro);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.cafe);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.akces);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "");
			map.put("number", R.drawable.ic_launcher);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.sponsor));
			map.put("number", R.drawable.gino);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.organiser));
			map.put("number", R.drawable.fundacja);
			fillMaps.add(map);

			l.setAdapter(new MyAdapter(getBaseContext(), fillMaps,
					R.layout.sponsors_item, from, to));

		} catch (Exception exc) {
			Toast.makeText(getBaseContext(), exc.toString(), 1).show();
		}
	}

	private class MyAdapter extends SimpleAdapter {

		Context context;

		@SuppressWarnings("deprecation")
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = super.getView(position, convertView, parent);
			try {

				ImageView image = (ImageView) view
						.findViewById(R.id.imageSponsor);
				image.setBackgroundDrawable(getResources().getDrawable(
						Integer.parseInt(fillMaps.get(position).get("number")
								.toString())));
				
				TextView tx=(TextView)view.findViewById(R.id.txSponsors);
				if(!fillMaps.get(position).get("number")
						.toString().equals(""))
				{
					tx.setVisibility(View.VISIBLE);
				}

			} catch (Exception exc) {
				Toast.makeText(getBaseContext(), exc.toString(), 1).show();
			}
			return view;

		}

		public MyAdapter(Context context, List<? extends Map<String, ?>> data,
				int resource, String[] from, int[] to) {

			super(context, data, resource, from, to);
			this.context = context;

		}
	}
}