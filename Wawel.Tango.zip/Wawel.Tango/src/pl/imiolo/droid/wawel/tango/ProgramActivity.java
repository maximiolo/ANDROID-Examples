package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.Toast;

@SuppressWarnings("deprecation")
public class ProgramActivity extends TabActivity {
	Bundle bundle;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_program);
		TangoEngine.LoadBaseData(getBaseContext());
		
		if (getIntent() != null && getIntent().getExtras() != null) {
			bundle = getIntent().getExtras();
			switch ((TangoEngine.showType) bundle.get(TangoEngine.showName)) {
			case Program:
				showProgram(false);
				break;
			case Milonga:
				showProgram(false);
				break;
			case WorkShop:
				showProgram(true);
				break;
			case MyEvents:
				showMyEvents();
				break;

			}
		}

	}

	private void showProgram(Boolean bWorkshop) {
		TabHost tabHost = getTabHost();

		Intent intent0 = new Intent().setClass(ProgramActivity.this,
				GridActivity.class);
		TabSpec tabSpec0 = null;
		TabSpec tabSpec1 = null;
		if (!bWorkshop) {
			intent0.putExtra(TangoEngine.day,
					TangoEngine.baseData.Days.get(1).Id);
			intent0.putExtra(TangoEngine.showName,
					(TangoEngine.showType) bundle.get(TangoEngine.showName));
			tabSpec0 = tabHost
					.newTabSpec("Wednesday")
					.setIndicator( TangoEngine.baseData.Days
									.get(1).DateTab)
					// ressources.getDrawable(R.drawable.icon_android_config))
					.setContent(intent0);

			Intent intent1 = new Intent().setClass(this, GridActivity.class);
			intent1.putExtra(TangoEngine.day,
					TangoEngine.baseData.Days.get(2).Id);
			intent1.putExtra(TangoEngine.showName,
					(TangoEngine.showType) bundle.get(TangoEngine.showName));
			tabSpec1 = tabHost
					.newTabSpec("Thursday")
					.setIndicator(
							 TangoEngine.baseData.Days
									.get(2).DateTab).setContent(intent1);
		}
		Intent intent2 = new Intent().setClass(this, GridActivity.class);
		intent2.putExtra(TangoEngine.day, TangoEngine.baseData.Days.get(3).Id);
		intent2.putExtra(TangoEngine.showName,
				(TangoEngine.showType) bundle.get(TangoEngine.showName));
		TabSpec tabSpec2 = tabHost
				.newTabSpec("Friday")
				.setIndicator(
						 TangoEngine.baseData.Days
								.get(3).DateTab).setContent(intent2);

		Intent intent3 = new Intent().setClass(this, GridActivity.class);
		intent3.putExtra(TangoEngine.day, TangoEngine.baseData.Days.get(4).Id);
		intent3.putExtra(TangoEngine.showName,
				(TangoEngine.showType) bundle.get(TangoEngine.showName));
		TabSpec tabSpec3 = tabHost
				.newTabSpec("Saturday")
				.setIndicator(
						 TangoEngine.baseData.Days
								.get(4).DateTab).setContent(intent3);

		Intent intent4 = new Intent().setClass(this, GridActivity.class);
		intent4.putExtra(TangoEngine.day, TangoEngine.baseData.Days.get(5).Id);
		intent4.putExtra(TangoEngine.showName,
				(TangoEngine.showType) bundle.get(TangoEngine.showName));
		TabSpec tabSpec4 = tabHost
				.newTabSpec("Sunday")
				.setIndicator(
						TangoEngine.baseData.Days
								.get(5).DateTab).setContent(intent4);
		if (!bWorkshop) {
			tabHost.addTab(tabSpec0);
			tabHost.addTab(tabSpec1);
		}
		tabHost.addTab(tabSpec2);
		tabHost.addTab(tabSpec3);
		tabHost.addTab(tabSpec4);
	}

	private void showMyEvents() {
		try {
			int[] myEvents = SharedPrefEvents.Instance(getBaseContext())
					.getMyEvents();
			List<Integer> lday = new ArrayList<Integer>();
			for (int i = 0; i < myEvents.length; i++) {
				if (!lday
						.contains(TangoEngine.baseData.Events.get(myEvents[i]).DayId)) {
					lday.add(TangoEngine.baseData.Events.get(myEvents[i]).DayId);
				}
			}

			Collections.sort(lday);

			if (myEvents.length > 0) {
				TabHost tabHost = getTabHost();
				TabSpec tabSpec0;
				Intent intent0;

				for (Integer day : lday) {
					intent0 = new Intent().setClass(ProgramActivity.this,
							GridActivity.class);

					intent0.putExtra(TangoEngine.day, day);
					intent0.putExtra(TangoEngine.showName,
							(TangoEngine.showType) bundle
									.get(TangoEngine.showName));
					tabSpec0 = tabHost
							.newTabSpec("Tab: " + day)
							.setIndicator(
									TangoEngine.baseData.Days
											.get(day).DateTab
											)
							// ressources.getDrawable(R.drawable.icon_android_config))
							.setContent(intent0);

					tabHost.addTab(tabSpec0);
				}
			}

		} catch (Exception exc) {
			Toast.makeText(getBaseContext(), exc.toString(), 1).show();
		}

	}

}