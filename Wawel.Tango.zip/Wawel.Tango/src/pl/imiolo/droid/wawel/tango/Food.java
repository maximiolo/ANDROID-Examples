package pl.imiolo.droid.wawel.tango;

public class Food {

	public int Id;
	public String Description;
	public String DescriptionPl;
	public int PlaceId;
}
