package pl.imiolo.droid.wawel.tango;

public class Hours {

	public int Id;
	public String Hour;
	public String HourPL;
}
