package pl.imiolo.droid.wawel.tango;

public class Day {

	public int Id;
	public String Name;
	public String NamePL;
	public String Date;
	public String DateTab;
}

