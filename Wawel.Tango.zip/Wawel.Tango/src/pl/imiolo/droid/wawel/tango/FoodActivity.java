package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class FoodActivity extends Activity {
	List<HashMap<String, Object>> fillMaps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_food);
		TangoEngine.LoadBaseData(getBaseContext());
		try {
			ListView l = (ListView) findViewById(R.id.listViewFood);

			String[] from = { "name", "desc", "place_id", "place" };
			int[] to = { R.id.txTimeFood, R.id.textViewFood, R.id.btnFood,
					R.id.btnFood };

			fillMaps = new ArrayList<HashMap<String, Object>>();

			for (int i = 1; i <= TangoEngine.baseData.Food.size(); i++) {
				HashMap<String, Object> map = new HashMap<String, Object>();
				map.put("name", TangoEngine.baseData.Places
						.get(TangoEngine.baseData.Food.get(i).PlaceId).Name);

				map.put("desc",
						SharedPrefEvents.Instance(getBaseContext())
								.getLanguage() ? TangoEngine.baseData.Food
								.get(i).DescriptionPl
								: TangoEngine.baseData.Food.get(i).Description);
				String temp = SharedPrefEvents.Instance(getBaseContext())
						.getLanguage() ? TangoEngine.streetPl : "";

				String temp1 = SharedPrefEvents.Instance(getBaseContext())
						.getLanguage() ? "" : TangoEngine.streetEn;
				String a = temp
						+ TangoEngine.baseData.Places
								.get(TangoEngine.baseData.Food.get(i).PlaceId).Street
						+ temp1;

				map.put("place", a);

				map.put("place_id", TangoEngine.baseData.Food.get(i).PlaceId);

				fillMaps.add(map);
			}
			l.setAdapter(new MyAdapter(getBaseContext(), fillMaps,
					R.layout.food_item, from, to));
		} catch (Exception exc) {
			Toast.makeText(getBaseContext(), exc.toString(), 1).show();
		}
	}

	private class MyAdapter extends SimpleAdapter {

		Context context;

		@SuppressWarnings("deprecation")
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = super.getView(position, convertView, parent);
			view.setBackgroundColor(getResources().getColor(R.color.gray_light));
			view.setAlpha(Float.parseFloat(getString(R.string.grid_opacity)));

			try {

				Button btn = (Button) view.findViewById(R.id.btnFood);
				btn.setTag(fillMaps.get(position).get("place_id"));
				btn.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Button imageMap = (Button) v;
						ShowMaps(Integer.parseInt(imageMap.getTag().toString()));
					}
				});

			} catch (Exception exc) {
				Toast.makeText(getBaseContext(), exc.toString(), 1).show();
			}
			return view;

		}

		public MyAdapter(Context context, List<? extends Map<String, ?>> data,
				int resource, String[] from, int[] to) {

			super(context, data, resource, from, to);
			this.context = context;

		}
	}

	private void ShowMaps(int id) {

		if (!GeoLocation.Instane(getBaseContext()).checkLocation()) {
			startActivity(GeoLocation.Instane(getBaseContext()).showGeo(id));
		} else {
			showDialog(id);
		}
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		final Integer idPlace = id;
		return new AlertDialog.Builder(this)
				.setTitle(R.string.maps)
				.setIcon(android.R.drawable.ic_dialog_map)
				.setMessage(R.string.maps_desc)
				.setPositiveButton(R.string.title_activity_other,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								startActivity(GeoLocation.Instane(
										getBaseContext()).showGeo(idPlace));
							}
						})
				.setNegativeButton("GoogleMaps",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								startActivity(GeoLocation.Instane(
										getBaseContext()).showGoogleMaps(
										idPlace));

							}
						}).create();
	}

}