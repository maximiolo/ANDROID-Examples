package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ListView;
import android.widget.SimpleAdapter;

public class NewsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_news);
		TangoEngine.LoadBaseData(getBaseContext());

		ListView l = (ListView) findViewById(R.id.listViewNews);

		String[] from = { "head", "details" };
		int[] to = { R.id.txHead, R.id.txDetails };

		List<HashMap<String, Object>> fillMap = new ArrayList<HashMap<String, Object>>();

		for (int i = TangoEngine.baseData.News.size(); i >=1; i--) {			
					HashMap<String, Object> map = new HashMap<String, Object>();
					map.put("head",
							SharedPrefEvents.Instance(getBaseContext())
									.getLanguage() ? TangoEngine.baseData.News
									.get(i).NamePl : TangoEngine.baseData.News
									.get(i).Name);
					map.put("details",
							SharedPrefEvents.Instance(getBaseContext())
									.getLanguage() ? TangoEngine.baseData.News
									.get(i).DescriptionPl
									: TangoEngine.baseData.News.get(i).Description);
					fillMap.add(map);
				}
				
		

		l.setAdapter(new MyAdapter(getBaseContext(), fillMap,
				R.layout.news_item, from, to));
	}

	private class MyAdapter extends SimpleAdapter {

		public MyAdapter(Context context, List<? extends Map<String, ?>> data,
				int resource, String[] from, int[] to) {
			super(context, data, resource, from, to);
			// TODO Auto-generated constructor stub
		}

		Context context;

		@SuppressWarnings("deprecation")
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = super.getView(position, convertView, parent);		
			view.setBackgroundColor(getResources().getColor(R.color.gray_light));
			view.setAlpha(Float.parseFloat(getString(R.string.grid_opacity)));
			return view;
		}
	}

}
