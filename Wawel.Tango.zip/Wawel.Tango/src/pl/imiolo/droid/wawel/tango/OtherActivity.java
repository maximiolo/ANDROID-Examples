package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class OtherActivity extends Activity {

	List<HashMap<String, Object>> fillMaps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_other);
		TangoEngine.LoadBaseData(getBaseContext());

		try {
			ListView l = (ListView) findViewById(R.id.listViewOther);

			String[] from = { "name", "image" };
			int[] to = { R.id.txOtherHead, R.id.imageIcon };

			fillMaps = new ArrayList<HashMap<String, Object>>();

			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("name", getString(R.string.legends));
			map.put("number", R.drawable.icon_legends);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.food));
			map.put("number", R.drawable.icon_food);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.shop));
			map.put("number", R.drawable.icon_shop);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.sponsors));
			map.put("number", R.drawable.icon_sponsors);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", getString(R.string.contact));
			map.put("number", R.drawable.icon_contact);
			fillMaps.add(map);

			map = new HashMap<String, Object>();
			map.put("name", "Taxi");
			map.put("number", R.drawable.taxi);
			fillMaps.add(map);

			l.setAdapter(new MyAdapter(getBaseContext(), fillMaps,
					R.layout.other_item, from, to));

			l.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					lunchIntent(arg2);

				}
			});
		} catch (Exception exc) {
			Toast.makeText(getBaseContext(), exc.toString(), 1).show();
		}
	}

	private class MyAdapter extends SimpleAdapter {

		Context context;

		@SuppressWarnings("deprecation")
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = super.getView(position, convertView, parent);
			view.setBackgroundColor(getResources().getColor(R.color.gray_light));
			view.setAlpha(Float.parseFloat(getString(R.string.grid_opacity)));
			try {

				ImageView image = (ImageView) view.findViewById(R.id.imageIcon);
				image.setBackgroundDrawable(getResources().getDrawable(
						Integer.parseInt(fillMaps.get(position).get("number")
								.toString())));

			} catch (Exception exc) {
				Toast.makeText(getBaseContext(), exc.toString(), 1).show();
			}
			return view;

		}

		public MyAdapter(Context context, List<? extends Map<String, ?>> data,
				int resource, String[] from, int[] to) {

			super(context, data, resource, from, to);
			this.context = context;

		}
	}

	private void lunchIntent(int id) {
		Intent intent = null;
		switch (id) {
		case 0:
			intent = new Intent(OtherActivity.this, LegendsActivity.class);
			intent.putExtra(TangoEngine.showMsg,
					TangoEngine.showMessage.Legends);

			break;
		case 1:
			intent = new Intent(OtherActivity.this, FoodActivity.class);
			intent.putExtra(TangoEngine.showMsg, TangoEngine.showMessage.Food);
			break;
		case 2:
			intent = new Intent(OtherActivity.this, ShoppActivity.class);
			intent.putExtra(TangoEngine.showMsg, TangoEngine.showMessage.Shopp);
			break;
		case 3:
			intent = new Intent(OtherActivity.this, SponsorsActivity.class);
			intent.putExtra(TangoEngine.showMsg,
					TangoEngine.showMessage.Sposors);
			break;
		case 4:
			intent = new Intent(OtherActivity.this, ContactActivity.class);
			break;
		case 5:
			intent = new Intent(Intent.ACTION_DIAL);
			intent.setData(Uri.parse("tel:122666666"));
			break;
		}
		startActivity(intent);
	}

}
