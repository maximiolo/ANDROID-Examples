package pl.imiolo.droid.wawel.tango;

import java.util.Map;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class SharedPrefEvents {
	private SharedPrefEvents(Context context) {
		super();
		this.context = context;
	}

	Context context;
	private static  SharedPrefEvents sp;
	public static SharedPrefEvents Instance(Context context)
	{
		if(sp==null)
		{
			sp=new SharedPrefEvents(context);
		}
		return sp;
	}
	
	public Boolean isEventAdded(int id) {
		SharedPreferences sp = context.getSharedPreferences(
				TangoEngine.myEvents, context.MODE_PRIVATE);
		int i = sp.getInt(String.valueOf(id), 0);
		return i == 1 ? true : false;
	}

	public void setEvent(int id, Boolean add) {
		SharedPreferences sp = context.getSharedPreferences(
				TangoEngine.myEvents, context.MODE_PRIVATE);
		
		Editor e = sp.edit();
		if (add)
			e.putInt(String.valueOf(id), 1);
		else
			e.remove(String.valueOf(id));
		e.commit();
	}
	
	public int[] getMyEvents()
	{
		
		SharedPreferences sp = context.getSharedPreferences(
				TangoEngine.myEvents, context.MODE_PRIVATE);
		int [] tab=new int[sp.getAll().size()];
		Map<String,?> keys= sp.getAll();
		int i=0;
		for(Map.Entry<String, ?> entry:keys.entrySet())
		{
			tab[i]=Integer.parseInt( entry.getKey());
			i++;
		}		
		return tab;
	}
	
	public Boolean getLanguage()
	{
		return context.getString(R.string.language).equals("1");
	}

}
