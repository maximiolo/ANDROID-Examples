package pl.imiolo.droid.wawel.tango;

public class News {
	public int Id;
	public String Name;
	public String Description;
	public String NamePl;
	public String DescriptionPl;
}

