package pl.imiolo.droid.wawel.tango;

public class Place {

	public int Id;
	public String Name;
	public String Street;
	public String Lonngitude;
	public String Latitude;
}

