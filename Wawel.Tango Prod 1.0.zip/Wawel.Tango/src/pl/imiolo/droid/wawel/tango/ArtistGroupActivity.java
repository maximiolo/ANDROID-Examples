package pl.imiolo.droid.wawel.tango;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;


public class ArtistGroupActivity extends Activity {

	List<HashMap<String, Object>> fillMaps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_artist_group);
		TangoEngine.LoadBaseData(getBaseContext());
		
		
			ListView l = (ListView) findViewById(R.id.listViewArtists);

			String[] from = { "name", "image" };
			int[] to = { R.id.txArtistName, R.id.imageViewArtist };

			fillMaps = new ArrayList<HashMap<String, Object>>();

			for (int i = 1; i < TangoEngine.baseData.Artists.size(); i++) {
				HashMap<String, Object> map = new HashMap<String, Object>();
				map.put("name", TangoEngine.baseData.Artists.get(i).Name);
				map.put("image", TangoEngine.baseData.Artists.get(i).Id);

				fillMaps.add(map);
			}
			l.setAdapter(new MyAdapter(getBaseContext(), fillMaps,
					R.layout.artist_item, from, to));
		
	}

	private class MyAdapter extends SimpleAdapter {

		Context context;

		@SuppressWarnings("deprecation")
		@TargetApi(Build.VERSION_CODES.HONEYCOMB)
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view = super.getView(position, convertView, parent);
			

				ImageView image = (ImageView) view
						.findViewById(R.id.imageViewArtist);

				switch (Integer.parseInt(fillMaps.get(position).get("image")
						.toString())) {
				case 1:
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.fabien));
					break;
				case 2:
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.pajero));
					break;
				case 3:
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.max));
					break;
				case 4:
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.venon));
					break;
				case 5:
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.otros));
					break;
				case 6:
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.hype));
					break;
				case 7:
					image.setBackgroundDrawable(getResources().getDrawable(
							R.drawable.giorgio));
					break;
				default:
					image.setBackgroundDrawable(null);
					break;
				}

			
			return view;

		}

		public MyAdapter(Context context, List<? extends Map<String, ?>> data,
				int resource, String[] from, int[] to) {

			super(context, data, resource, from, to);
			this.context = context;

		}
	}

}
