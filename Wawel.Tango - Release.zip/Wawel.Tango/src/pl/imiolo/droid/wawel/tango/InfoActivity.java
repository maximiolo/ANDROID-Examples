package pl.imiolo.droid.wawel.tango;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class InfoActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_info);
	}

	public void send(View view) {
		ImageView v = (ImageView) view;

		Intent mailer = new Intent(Intent.ACTION_SEND);
		mailer.setType("text/plain");
		mailer.putExtra(Intent.EXTRA_EMAIL, new String[] { v.getTag()
				.toString() });
		mailer.putExtra(Intent.EXTRA_SUBJECT, "");
		mailer.putExtra(Intent.EXTRA_TEXT, "");
		startActivity(Intent.createChooser(mailer, "Send email..."));

	}
}
