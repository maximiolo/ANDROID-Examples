package pl.imiolo.droid.wawel.tango;

public class Name {
	public int Id;
	public String Name;
	public String NamePL;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return Name;
	}

}
