package pl.imiolo.droid.wawel.tango;

public class Contact {

	public int Id;
	public String Name;
	public String Number;
	public String Language;	
}
