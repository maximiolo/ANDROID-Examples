package pl.imiolo.droid.wawel.tango;

import java.util.Map;

public class BaseData {

	public Map<Integer, Events> Events;
	public Map<Integer, Artist> Artists;
	public Map<Integer, Day> Days;
	public Map<Integer, Hours> Hours;
	public Map<Integer, Name> Names;
	public Map<Integer, Place> Places;
	public Map<Integer, News> News;
	public Map<Integer, Contact> Contact;
	//public Map<Integer, News> Others;
	public Map<Integer, Food> Food;
	public Shopp Shoop;
	public Map<Integer, News> Legends;
}

